import 'package:flutter/material.dart';

class AppPallete {
  static const Color backgroundColor = Color(0xFFFFFFFF);
  static const Color detailsBackgroundColor = Color(0xFFFEB5A7);
  static const Color gradient1 = Color.fromRGBO(187, 63, 221, 1);
  static const Color gradient2 = Color.fromRGBO(251, 109, 169, 1);
  static const Color gradient3 = Color.fromRGBO(255, 159, 124, 1);
  static const Color borderColor = Color.fromRGBO(52, 51, 67, 1);
  static const Color cardBackgroundColor1 = Color(0xFFDDE1F2);
  static const Color cardBackgroundColor2 = Color(0xFFF8EBE7);
  static const Color greyColor = Colors.grey;
  static const Color errorColor = Colors.redAccent;
  static const Color transparentColor = Colors.transparent;
}
