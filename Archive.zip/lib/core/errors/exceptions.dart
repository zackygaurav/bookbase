class ServerException implements Exception {
  final String message;

  // Constructor
  ServerException({required this.message});
}
